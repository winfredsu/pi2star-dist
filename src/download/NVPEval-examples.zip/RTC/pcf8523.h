#include "reg51.h"
#include "i2c.h"
#include "delay.h"
#include "stdio.h"

#define PCF_SLA_ADDR 0xD0
#define REG_CTRL1 0x00
#define REG_CTRL2 0x01
#define REG_CTRL3 0x02
#define REG_TSECD 0x03
#define REG_TMINU 0x04
#define REG_THOUR 0x05
#define REG_TDAYS 0x06
#define REG_TWEEK 0x07
#define REG_TMONS 0x08
#define REG_TYEAR 0x09
#define REG_AMINU 0x0A
#define REG_AHOUR 0x0B
#define REG_ADAYS 0x0C
#define REG_AWEEK 0x0D
#define REG_OFFST 0x0E
#define REG_CLKOT 0x0F
#define REG_TMRAF 0x10
#define REG_TMRAR 0x11
#define REG_TMRBF 0x12
#define REG_TMRBR 0x13

void pcfPre();
void pcfInit();
void pcfReset();
void pcfReadDate(int* year, int* month, int* day, int* weekday);
void pcfReadTime(int* hour, int* minute, int* second);

