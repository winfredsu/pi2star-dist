/*****************************************/
/* configuration funcions of temperature */
/* sensor tmp100						 */
/*****************************************/
#include "pcf8523.h"
#include "i2c.h"
#include "LCD.h"

/*****************************************/
/* Prepare of pcf8523					 */
/*****************************************/
void pcfPre(){
	I2C_initial();
	I2C_rst();
}
/*****************************************/
/* INITIAL FUNCTION of pcf8523			 */
/* 32.768 kHz CLKOUT active				 */
/* 24 hour Mode; Offset = 0;			 */
/* No Alarm; No timer; No interrupts;	 */
/* Battery switch-over disabled;		 */
/* Battery low detection disabled;		 */
/* internal oscillator capacitor: 7pF.	 */
/* Calendar Back to zero				 */
/*****************************************/
void pcfInit(){
	uchar cmd;
	
	pcfPre();

	cmd = 0x00;
	I2C_w(PCF_SLA_ADDR, REG_CTRL1, &cmd, 1);
	cmd = 0x00;
	I2C_w(PCF_SLA_ADDR, REG_CTRL2, &cmd, 1);
	cmd = 0xE0;
	I2C_w(PCF_SLA_ADDR, REG_CTRL3, &cmd, 1);
	cmd = 0x80;		// Seconds	( 1_xxxxxxx )(0-59)
	I2C_w(PCF_SLA_ADDR, REG_TSECD, &cmd, 1);
	cmd = 0x00;		// Minutes	( 0_xxxxxxx )(0-59)
	I2C_w(PCF_SLA_ADDR, REG_TMINU, &cmd, 1);
	cmd = 0x00;		// Hours	( 00_xxxxxx )(0-23)/( 00_x_xxxxx )(1-12)
	I2C_w(PCF_SLA_ADDR, REG_THOUR, &cmd, 1);
	cmd = 0x00;		// Days		( 00_xxxxxx )(1-31)
	I2C_w(PCF_SLA_ADDR, REG_TDAYS, &cmd, 1);
	cmd = 0x00;		// Weekdays	( 00000_xxx )(0-6)
	I2C_w(PCF_SLA_ADDR, REG_TWEEK, &cmd, 1);
	cmd = 0x00;		// Months	( 000_xxxxx )(1-12)
	I2C_w(PCF_SLA_ADDR, REG_TMONS, &cmd, 1);
	cmd = 0x00;		// Years	( _xxxxxxxx )(1-99)
	I2C_w(PCF_SLA_ADDR, REG_TYEAR, &cmd, 1);
	cmd = 0x80;		// Minutes	( 1__xxxxxxx )(0-59)
	I2C_w(PCF_SLA_ADDR, REG_AMINU, &cmd, 1);
	cmd = 0x80;	   	// Hours	( 1_0_xxxxxx )(0-23)/( 1_0_x_xxxxx )(1-12)
	I2C_w(PCF_SLA_ADDR, REG_AHOUR, &cmd, 1);
	cmd = 0x80;	   	// Days		( 1_0_xxxxxx )(1-31)
	I2C_w(PCF_SLA_ADDR, REG_ADAYS, &cmd, 1);
	cmd = 0x80;		// Weekdays	( 1_0000_xxx )(0-6)
	I2C_w(PCF_SLA_ADDR, REG_AWEEK, &cmd, 1);
	cmd = 0x00;		// offset
	I2C_w(PCF_SLA_ADDR, REG_OFFST, &cmd, 1);
	cmd = 0x00;
	I2C_w(PCF_SLA_ADDR, REG_CLKOT, &cmd, 1);
	cmd = 0x07;
	I2C_w(PCF_SLA_ADDR, REG_TMRAF, &cmd, 1);
	cmd = 0x00;
	I2C_w(PCF_SLA_ADDR, REG_TMRAR, &cmd, 1);
	cmd = 0x07;
	I2C_w(PCF_SLA_ADDR, REG_TMRBF, &cmd, 1);
	cmd = 0x00;
	I2C_w(PCF_SLA_ADDR, REG_TMRBR, &cmd, 1);
}
/*****************************************/
/* RESET FUNCTION of pcf8523			 */
/* 32.768 kHz CLKOUT active				 */
/* 24 hour Mode; Offset = 0;			 */
/* No Alarm; No timer; No interrupts;	 */
/* Battery switch-over disabled;		 */
/* Battery low detection disabled;		 */
/* internal oscillator capacitor: 7pF.	 */
/*****************************************/
void pcfReset(){
	uchar cmd;

	I2C_initial();
	I2C_rst();

	cmd = 0x58;
	I2C_w(PCF_SLA_ADDR, REG_CTRL1, &cmd, 1);
}
/*****************************************/
/* Read Date of pcf8523			 */
/*****************************************/
void pcfReadDate(int* year, int* month, int* day, int* weekday){
	uchar cmd, time, mode;

	// Set OS = 1;
	I2C_r(PCF_SLA_ADDR, REG_TSECD, &cmd, 1);
	if(~(cmd&0x80))
		cmd |= 0x80;
	I2C_w(PCF_SLA_ADDR, REG_TSECD, &cmd, 1);

	// Read Date
	// day
	I2C_r(PCF_SLA_ADDR, REG_TDAYS, &time, 1);
	day[0] = (time<<4)>>4;
	day[1] = (time<<2)>>6;
	// weekday
	I2C_r(PCF_SLA_ADDR, REG_TWEEK, &time, 1);
	*weekday = time;
	// month
	I2C_r(PCF_SLA_ADDR, REG_TMONS, &time, 1);
	month[0] = (time<<4)>>4;
	month[1] = (time<<3)>>7;
	// year
	I2C_r(PCF_SLA_ADDR, REG_TYEAR, &time, 1);
	year[0] = (time<<4)>>4;
	year[1] = time>>4;

	// Set OS = 0;
	cmd &= ~0x80;
	I2C_w(PCF_SLA_ADDR, REG_TSECD, &cmd, 1);
}


/*****************************************/
/* Read Time of pcf8523			 */
/*****************************************/
void pcfReadTime(int* hour, int* minute, int* second){
	uchar cmd, time, mode;

	// Set OS = 1;
	I2C_r(PCF_SLA_ADDR, REG_TSECD, &cmd, 1);
	if(~(cmd&0x80))
		cmd |= 0x80;
	I2C_w(PCF_SLA_ADDR, REG_TSECD, &cmd, 1);

	// Get hour mode
	I2C_r(PCF_SLA_ADDR, REG_CTRL1, &mode, 1);
	mode &= 0x08;

	// Read Time
	// second
	I2C_r(PCF_SLA_ADDR, REG_TSECD, &time, 1);
	second[0] = (time<<4)>>4;
	second[1] = (time<<1)>>5;
	// minutes
	I2C_r(PCF_SLA_ADDR, REG_TMINU, &time, 1);
	minute[0] = (time<<4)>>4;
	minute[0] = (time<<1)>>5;
	// hours	
	I2C_r(PCF_SLA_ADDR, REG_THOUR, &time, 1);
	if(mode){
		hour[0] = (time<<4)>>4;
		hour[1] = (time<<3)>>7;
		hour[2] = (time<<2)>>7;}
	else{
		hour[0] = (time<<4)>>4;
		hour[1] = (time<<2)>>6;
		hour[2] = 0xFF;}

	// Set OS = 0;
	cmd &= ~0x80;
	I2C_w(PCF_SLA_ADDR, REG_TSECD, &cmd, 1);
}