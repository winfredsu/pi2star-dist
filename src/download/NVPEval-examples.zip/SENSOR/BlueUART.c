#include "BlueUART.h"

// UART baud rate is 600
void delay(int n)
{ 
	while(--n) ;
}

void WByte(uchar input){
    uchar j = 0;
    TX = 0;                    
    //mynop();
	delay(14);

	if(input & 0x01)
		TX=1;
		else
		TX=0;
	delay(14);
	input = input >> 1;
  	if(input & 0x01)
		TX=1;
		else
		TX=0;
	delay(14);
	input = input >> 1;
	if(input & 0x01)
		TX=1;
		else
		TX=0;
	delay(14);
	input = input >> 1;
	if(input & 0x01)
		TX=1;
		else
		TX=0;
	delay(14);
	input = input >> 1;
	if(input & 0x01)
		TX=1;
		else
		TX=0;
	delay(14);
	input = input >> 1;
	if(input & 0x01)
		TX=1;
		else
		TX=0;
	delay(14);
	input = input >> 1;
	if(input & 0x01)
		TX=1;
		else
		TX=0;
	delay(14);
	input = input >> 1;
	if(input & 0x01)
		TX=1;
		else
		TX=0;
	delay(14);
	//input = input >> 1;

    TX = 1;
    wait(1,500);                    
}
void BlueTooth_Send(char* msg, uint len){
	uint i;
	for(i=0;i<len;i++){
		WByte(msg[i]);
	}
}
